/**小游戏跳转数据 */
var MiniGameData = [
    {
        id:1,
        name:"丛林扫雷",
        icon:"Game/app_1.png",
        dic:"经典扫雷游戏，化身丛林冒险，快来挑战一下吧!",
        appId:"wx8c5573d6925aa12e",
    },
    {
        id:2,
        name:"小熊猫泡泡龙",
        icon:"Game/app_2.png",
        dic:"经典泡泡龙，物理引擎，丰富到家，泡泡弹弹弹，根本停不下来！",
        appId:"wx7379c695b4a447c1",
    },
    {
        id:3,
        name:"全民打鸭子",
        icon:"Game/app_3.png",
        dic:"FC小霸王时代的经典打鸭子，挑战你的反应能力，冲鸭!",
        appId:"wxa189aa468950a10a",
    },
    {
        id:4,
        name:"全民大战僵尸",
        icon:"Game/app_4.png",
        dic:"全民打僵尸，看见僵尸就打！一定要看清楚！",
        appId:"wxd400af25f85304d2",
    },
    {
        id:5,
        name:"全民飞刀",
        icon:"Game/app_5.png",
        dic:"旋转跳跃飞刀不停歇，把握力度，看准时机，让飞刀跳上台阶！",
        appId:"wx1c5ac4f16e187de5",
    },
    // {
    //     id:6,
    //     name:"全民滑雪球",
    //     icon:"Game/app_6.png",
    //     dic:"惊险刺激，看准时机，控制雪球滑的更远，开启滑雪大冒险!",
    //     appId:"wx128d2a687fa61582",
    // },
    {
        id:7,
        name:"全民来找茬",
        icon:"Game/app_7.png",
        dic:"天天找不同，考验手速与眼力的时候到了，大家来找茬吧！",
        appId:"wx77dc1ebeabaae083",
    },
    {
        id:8,
        name:"全民养膘",
        icon:"Game/app_8.png",
        dic:"在回转寿司里计算体重，大家一起来养膘，囤积我的卡路里!",
        appId:"wxce4373d549798b17",
    },
    {
        id:8,
        name:"飞驰人生一战到底",
        icon:"Game/app_9.png",
        dic:"人生没有退路，只有不断向前！创意简笔画风游戏。",
        appId:"wx405cbaf0509b2e29",
    },
    
    
];