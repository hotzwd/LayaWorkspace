var window = window || this;
var document = document || (window.document = {});